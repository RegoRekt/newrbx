<h1 align="center"><img src="https://github.com/pizzaboxer/bloxstrap/raw/main/Images/Bloxstrap.png" width="24"/> rbxflags</h1>

<h2 align="center">Repository Intent</h2>

* This list exists purely for the purposes of learning more about the inner workings of our favourite games.
* We do not endorse the use of this information for activities that break Roblox's [Terms of Use](https://en.help.roblox.com/hc/en-us/articles/115004647846-Roblox-Terms-of-Use) or any other applical legal documents.
* We do not condone the use of this information for unfair purposes, such as gaining an advantage over others.

<h2 align="center">Legal Disclaimer</h2>

This list exists purely for the purposes of learning more about the inner workings of our favourite games. We do not endorse the use of this information for activities that break Roblox's [Terms of Use](https://en.help.roblox.com/hc/en-us/articles/115004647846-Roblox-Terms-of-Use) or any other applical legal documents. We also do not condone the use of this information for unfair purposes, such as gaining an advantage over others.

By continuing to read this document, you agree that you have read and agree with this repository's Terms and Conditions. If you do not agree, stop reading this document now.

<h2 align="center">Safety Warning</h2>

> Fast Flags are extremely powerful, being that they are intended to only be used by Roblox engineers. While they can be very useful, they can cause issues with stability and functionality if you don't know what you're doing.
> 
> You should only use the flag list editor if you know what you're doing. You should only configure flags of which you fully know what they do.
> 
> We especially do not recommend importing any large lists of flags, for all the reasons stated above. If you're encountering any issues with Roblox, your first action should be to remove anything you've manually configured in the editor.
>
> &nbsp;&nbsp;-&nbsp;&nbsp; [Bloxstrap Fast Flags Documentation](https://github.com/pizzaboxer/bloxstrap/wiki/A-guide-to-FastFlags)

As stated in this repository's Terms and Conditions, by using the information in this repository you relieve it's creator(s) of any liability caused by your use, including legal and financial liability.

By accessing this repository, you agree that you have read and agree with this repository's Terms and Conditions. If you do not agree, cease accessing this rentry immediately.

<h3 align="center">
  <img src="assets/ffcollective.jpg" width="128" alt="luafv">
</h3>
<h4 align="center">© 2024 luafv All Rights Reserved.</h4>
