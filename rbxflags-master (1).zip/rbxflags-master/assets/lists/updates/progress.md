## Main List
### FastFlags
- [x] Flag Cleanup 2
- [x] Make everything we have public
### Alerts Style Revamp
- [x] Rendering
- [x] Lightning Technologies
- [x] Graphical Settings
- [x] QoL
- [x] UI
- [x] UI X
- [x] Physics
- [x] Abusive Visuals
- [x] lol
- [x] Debug
- [x] Links
## Other Stuff
- [x] Assign new maintainers
